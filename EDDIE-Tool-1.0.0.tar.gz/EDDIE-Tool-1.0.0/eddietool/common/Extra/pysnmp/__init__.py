"""The SNMP engine module. Includes BER encoder/decoder for SNMP subset
   of ASN.1 data types and a few network transports.
"""   
